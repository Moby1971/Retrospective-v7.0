% set Matlab path and TOOLBOX_PATH environment variable
addpath(fullfile(pwd, 'matlab'));
setenv('TOOLBOX_PATH', pwd);

