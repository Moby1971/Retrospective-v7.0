
extern const double bart_logo[77][2][4];
	
