

extern int polygon_winding_number(int N, const double pg[N][2], const double p[2]);
extern double polygon_area(int N, const double pos[N][2]);
 

