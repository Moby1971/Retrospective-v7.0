This folder is to save the simulations done by estvar/nsv.
