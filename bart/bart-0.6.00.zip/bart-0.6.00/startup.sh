# set environment variables

#export OMP_NUM_THREADS=23
export TOOLBOX_PATH=`pwd`
export PATH=${TOOLBOX_PATH}:${PATH}

