
struct linop_s;


extern float linop_test_adjoint(const struct linop_s* op);
extern float linop_test_adjoint_real(const struct linop_s* op);
extern float linop_test_normal(const struct linop_s* op);
extern float linop_test_inverse(const struct linop_s* op);

